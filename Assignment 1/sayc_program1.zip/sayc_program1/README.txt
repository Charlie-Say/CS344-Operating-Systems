CS 344 - Operating Systems
Program 1

ONID: sayc
OSU ID: 934377368

1. To compile the code

    - Locate directory of code files

    - Unzip files with command in terminal:
	$ "unzip file_name_here" (without quotes)
	example: $ unzip sayc_program1.zip

    - Locate directory of unzipped files

    - At the command line type in:
	$ "gcc -o movies main.c"	(without the quotes)

    - This will create a the file "movies" to execute


2. Running the program

    - At the command line type in:
	$ "./movies your_file_name_directory"	(without quotes)
        example: $ ./movies movies_sample_1.csv

    - This will execute the program with the file name as the argument